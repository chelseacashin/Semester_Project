import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Readfile {
    public static void main(String[] args) {
        ArrayList<StockRecord> records = new ArrayList<>();  // declared an array list full of objects so they can keep being added on to
        String title = "";
        try {
            File myObj = new File("Market data_2025/AAPL_2025.csv");
            String fileName = myObj.getName();  // "AAPL_2025.csv"
            title = fileName.replace(".csv", "");  // "AAPL_2025"
            Scanner myReader = new Scanner(myObj);

            if (myReader.hasNextLine()) {
                myReader.nextLine();  // skips the header row (Date, open, high,...)
            }

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine(); //saves all the data into a big string
                String[] parts = data.split(","); //splits the data into separate string to put into this list

                if (parts.length < 6) continue;  // skip blank/bad lines
                // creates a new class StockRecord called r
                StockRecord r = new StockRecord(
                        //keeps the String elements as String and converts the rest into double or long
                        //these all are the parameters going into the class
                        parts[0].trim(),
                        Double.parseDouble(parts[1].trim()),
                        Double.parseDouble(parts[2].trim()),
                        Double.parseDouble(parts[3].trim()),
                        Double.parseDouble(parts[4].trim()),
                        Long.parseLong(parts[5].trim())
                );
                records.add(r);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        System.out.println("=== " + title + " ===");
        System.out.println("Loaded " + records.size() + " rows"); //just lets the user know how many rows were loaded
        for (StockRecord r : records) {
            System.out.println(r);
        }
    }
}