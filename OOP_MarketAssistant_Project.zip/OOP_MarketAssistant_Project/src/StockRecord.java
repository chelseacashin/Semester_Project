public class StockRecord {
    // initializes the variables that the class will contain
    private String date;
    private double open;
    private double high;
    private double low;
    private double close;
    private long volume;
    // creates the class with all the parameters
    public StockRecord(String date, double open, double high,
                       double low, double close, long volume) {
        // makes all the outside variables equal the data put through the parameters
        this.date = date;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
    }
    //these are methods to obtain certain values
    public String getDate()  { return date; }
    public double getOpen()  { return open; }
    public double getHigh()  { return high; }
    public double getLow()   { return low; }
    public double getClose() { return close; }
    public long getVolume()  { return volume; }
    // this overrides the default string that would print and replaces it with this to make the data readable
    @Override
    public String toString() {
        return date + " | O:" + open + " H:" + high + " L:" + low
                + " C:" + close + " V:" + volume;
    }
}